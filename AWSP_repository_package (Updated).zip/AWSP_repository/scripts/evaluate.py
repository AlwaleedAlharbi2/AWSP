"""
Main evaluation script for AWSP++ vs. all baselines.

Usage:
    python scripts/evaluate.py --dataset Google --seeds 17 42 73 128 257
    python scripts/evaluate.py --all
    python scripts/evaluate.py --all --n_vms 10000  # quick smoke test

Outputs:
    results/<dataset>_<algo>_seed<s>.json    per-seed PlacementResult
    results/table5_reproduction.csv          Table 5 reproduction
    results/table8_stats.csv                 Table 8 statistical tests
"""

from __future__ import annotations
import argparse
import copy
import json
import os
import sys
import numpy as np
import pandas as pd
from pathlib import Path

# Allow running from repo root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.models import Host, PlacementResult, N_RES
from src.awsp_plus import awsp_plus_policy, DEFAULT_THETA, DEFAULT_WEIGHTS
from src.simulator import Simulator
from src.baselines import BASELINES
from utils.data_loader import DATASET_META, LOADERS
from utils.metrics import aggregate_seeds, format_table5_row
from utils.paired_ttest import paired_ttest_bonferroni

SEEDS    = [17, 42, 73, 128, 257]
RESULTS_DIR = Path("results")

# Default host fleet per dataset (Table 2 in paper)
def build_hosts(dataset: str) -> list:
    meta  = DATASET_META[dataset]
    n     = meta["n_hosts"]
    caps  = meta["capacities"].copy()
    return [
        Host(host_id=i, capacities=caps.copy())
        for i in range(n)
    ]


def run_one(algo_name: str, policy, dataset: str, seed: int,
            n_vms: int = 0) -> PlacementResult:
    """Run a single (algorithm, dataset, seed) trial."""
    loader = LOADERS[dataset]
    if dataset == "Bitbrains":
        vms, meta = loader(seed=seed)
    else:
        kwargs = {"seed": seed}
        if n_vms > 0:
            kwargs["n_vms"] = n_vms
        vms, meta = loader(**kwargs)

    hosts = build_hosts(dataset)
    sim   = Simulator(
        hosts, policy,
        theta   = DEFAULT_THETA,
        weights = DEFAULT_WEIGHTS,
        alpha   = 1.0,
        beta    = 0.5,
        k       = 4,
        seed    = seed,
    )
    result = sim.run(vms, window=meta["window"],
                     dataset=dataset, algorithm=algo_name, seed=seed)
    return result


def results_to_dict(r: PlacementResult) -> dict:
    return {
        "algorithm":       r.algorithm,
        "dataset":         r.dataset,
        "seed":            r.seed,
        "active_hosts":    r.active_hosts,
        "energy_kwh":      r.energy_kwh,
        "weighted_slack":  r.weighted_slack,
        "sla_rate":        r.sla_rate,
        "migration_count": r.migration_count,
        "avg_decision_ms": r.avg_decision_ms,
    }


def save_result(r: PlacementResult, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    fname = out_dir / f"{r.dataset}_{r.algorithm}_seed{r.seed}.json"
    with open(fname, "w") as f:
        json.dump(results_to_dict(r), f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="AWSP++ evaluation suite")
    parser.add_argument("--dataset",  default="Google",
                        choices=list(DATASET_META.keys()))
    parser.add_argument("--algo",     default="all",
                        help="Algorithm name or 'all'")
    parser.add_argument("--seeds",    nargs="+", type=int, default=SEEDS)
    parser.add_argument("--all",      action="store_true",
                        help="Run all algorithms on all datasets")
    parser.add_argument("--n_vms",    type=int, default=0,
                        help="Limit VM count (0 = full dataset)")
    args = parser.parse_args()

    all_policies = {"AWSP++": awsp_plus_policy, **BASELINES}

    if args.algo != "all":
        policies_to_run = {args.algo: all_policies[args.algo]}
    else:
        policies_to_run = all_policies

    datasets_to_run = (list(DATASET_META.keys()) if args.all
                       else [args.dataset])

    all_results: dict = {}   # {algo: {dataset: [PlacementResult]}}

    for dataset in datasets_to_run:
        for algo_name, policy in policies_to_run.items():
            print(f"\n[{algo_name}] {dataset}:", end=" ", flush=True)
            all_results.setdefault(algo_name, {})[dataset] = []
            for seed in args.seeds:
                print(f"seed={seed}", end=" ", flush=True)
                r = run_one(algo_name, policy, dataset, seed, args.n_vms)
                all_results[algo_name][dataset].append(r)
                save_result(r, RESULTS_DIR)
            print()

    # Aggregate and print Table 5 reproduction
    print("\n" + "=" * 80)
    print("Table 5 Reproduction (Python simulator)")
    print("=" * 80)
    agg = aggregate_seeds(
        {a: {d: rs for d, rs in dm.items()}
         for a, dm in all_results.items()}
    )
    rows = []
    for algo in ["AWSP++", "PABFD", "GRVMP", "LBMBP",
                 "Entropy-VMP", "HUNTER", "K-RL-VMP"]:
        for dataset in datasets_to_run:
            if algo in agg and dataset in agg[algo]:
                line = format_table5_row(algo, dataset, agg[algo][dataset])
                print(line)
                rows.append(agg[algo][dataset] | {"algorithm": algo,
                                                   "dataset": dataset})

    # Save CSV
    if rows:
        RESULTS_DIR.mkdir(exist_ok=True)
        df = pd.DataFrame(rows)
        df.to_csv(RESULTS_DIR / "table5_reproduction.csv", index=False)
        print(f"\nSaved: {RESULTS_DIR}/table5_reproduction.csv")


if __name__ == "__main__":
    main()
