"""
Sensitivity analysis for AWSP++ hyper-parameters (Section V-C).

Sweeps:
  1. Headroom factor theta in {0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90}
  2. Sampling size k in {1, 2, 3, 4, 6, 8, 12}
  3. Weight vector (wCPU, wRAM, wBW) across 5 representative configurations

Usage:
    python scripts/sensitivity_analysis.py --param theta
    python scripts/sensitivity_analysis.py --param k
    python scripts/sensitivity_analysis.py --param weights
    python scripts/sensitivity_analysis.py --all
"""

from __future__ import annotations
import argparse
import sys
import numpy as np
import pandas as pd
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.models import Host
from src.awsp_plus import awsp_plus_policy, DEFAULT_THETA, DEFAULT_WEIGHTS
from src.simulator import Simulator
from utils.data_loader import DATASET_META, LOADERS

SEEDS_SENS = [42, 128]   # quick 2-seed sweep for sensitivity
DATASET    = "Google"

THETA_SWEEP   = [0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90]
K_SWEEP       = [1, 2, 3, 4, 6, 8, 12]
WEIGHT_SWEEP  = [
    (0.6, 0.3, 0.1, "CPU-heavy"),
    (0.4, 0.4, 0.2, "Balanced (default)"),
    (0.3, 0.6, 0.1, "RAM-heavy"),
    (0.5, 0.3, 0.2, "CPU+BW"),
    (0.33, 0.33, 0.34, "Uniform"),
]


def build_hosts(dataset: str):
    meta = DATASET_META[dataset]
    return [Host(host_id=i, capacities=meta["capacities"].copy())
            for i in range(meta["n_hosts"])]


def run_sweep(params_name: str, param_values: list, get_kwargs,
              n_vms: int = 0) -> pd.DataFrame:
    rows = []
    for pval in param_values:
        kwargs = get_kwargs(pval)
        energies, hosts_used = [], []
        for seed in SEEDS_SENS:
            loader = LOADERS[DATASET]
            kw = {"seed": seed}
            if n_vms > 0:
                kw["n_vms"] = n_vms
            vms, meta = loader(**kw)

            hosts = build_hosts(DATASET)
            sim   = Simulator(
                hosts, awsp_plus_policy,
                seed = seed,
                **kwargs,
            )
            r = sim.run(vms, window=meta["window"],
                        dataset=DATASET, algorithm="AWSP++", seed=seed)
            energies.append(r.energy_kwh)
            hosts_used.append(r.active_hosts)

        rows.append({
            "param":          params_name,
            "value":          str(pval),
            "mean_energy":    float(np.mean(energies)),
            "std_energy":     float(np.std(energies, ddof=1)),
            "mean_hosts":     float(np.mean(hosts_used)),
            "std_hosts":      float(np.std(hosts_used, ddof=1)),
        })
        print(f"  {params_name}={pval}: E={rows[-1]['mean_energy']:.2f} kWh, "
              f"H={rows[-1]['mean_hosts']:.0f}")
    return pd.DataFrame(rows)


def sensitivity_theta(n_vms):
    print("\n-- Theta sweep --")
    def get_kwargs(theta_val):
        return dict(
            theta   = np.full(3, theta_val),
            weights = DEFAULT_WEIGHTS,
            alpha   = 1.0, beta = 0.5, k = 4,
        )
    return run_sweep("theta", THETA_SWEEP, get_kwargs, n_vms)


def sensitivity_k(n_vms):
    print("\n-- k sweep --")
    def get_kwargs(k_val):
        return dict(
            theta   = DEFAULT_THETA,
            weights = DEFAULT_WEIGHTS,
            alpha   = 1.0, beta = 0.5, k = k_val,
        )
    return run_sweep("k", K_SWEEP, get_kwargs, n_vms)


def sensitivity_weights(n_vms):
    print("\n-- Weight sweep --")
    rows = []
    for wCPU, wRAM, wBW, label in WEIGHT_SWEEP:
        w = np.array([wCPU, wRAM, wBW])
        energies, hosts_used = [], []
        for seed in SEEDS_SENS:
            loader = LOADERS[DATASET]
            kw = {"seed": seed}
            if n_vms > 0:
                kw["n_vms"] = n_vms
            vms, meta = loader(**kw)
            hosts = build_hosts(DATASET)
            sim = Simulator(
                hosts, awsp_plus_policy,
                theta=DEFAULT_THETA, weights=w,
                alpha=1.0, beta=0.5, k=4, seed=seed,
            )
            r = sim.run(vms, window=meta["window"],
                        dataset=DATASET, algorithm="AWSP++", seed=seed)
            energies.append(r.energy_kwh)
            hosts_used.append(r.active_hosts)
        rows.append({
            "param": "weights", "value": label,
            "wCPU": wCPU, "wRAM": wRAM, "wBW": wBW,
            "mean_energy": float(np.mean(energies)),
            "mean_hosts":  float(np.mean(hosts_used)),
        })
        print(f"  w=({wCPU},{wRAM},{wBW}) [{label}]: "
              f"E={rows[-1]['mean_energy']:.2f} kWh")
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description="AWSP++ sensitivity analysis")
    parser.add_argument("--param", default="theta",
                        choices=["theta", "k", "weights", "all"])
    parser.add_argument("--n_vms", type=int, default=5000,
                        help="VM count per run (default 5000 for speed)")
    args = parser.parse_args()

    out_dir = Path("results")
    out_dir.mkdir(exist_ok=True)

    if args.param in ("theta", "all"):
        df = sensitivity_theta(args.n_vms)
        df.to_csv(out_dir / "sensitivity_theta.csv", index=False)
        print(f"Saved: {out_dir}/sensitivity_theta.csv")

    if args.param in ("k", "all"):
        df = sensitivity_k(args.n_vms)
        df.to_csv(out_dir / "sensitivity_k.csv", index=False)
        print(f"Saved: {out_dir}/sensitivity_k.csv")

    if args.param in ("weights", "all"):
        df = sensitivity_weights(args.n_vms)
        df.to_csv(out_dir / "sensitivity_weights.csv", index=False)
        print(f"Saved: {out_dir}/sensitivity_weights.csv")


if __name__ == "__main__":
    main()
