"""
Ablation study script for AWSP++ (Table 6 in the paper).

Ablation variants (four configurations):
  AWSP-M1  : AWSP++ without M1 (no bucket index, uniform random sampling)
  AWSP-M12 : AWSP++ without M3 (M1+M2 only, use random tie-breaking)
  AWSP-M3  : AWSP++ without M1/M2 (M3 scoring on all feasible hosts — O(|H|))
  AWSP++   : Full algorithm (M1+M2+M3)

Table 6 headline values (paper):
  AWSP-M1  Google: H=1671, E=449.3, Slack=11.94, SLA=2.47%
  AWSP-M12 Google: H=1603, E=427.8, Slack=12.88, SLA=1.93%
  AWSP-M3  Google: H=1537, E=408.1, Slack=13.79, SLA=1.38%
  AWSP++   Google: H=1502, E=402.8, Slack=14.07, SLA=1.18%

Usage:
    python scripts/ablation_study.py --dataset Google --seeds 17 42 73
    python scripts/ablation_study.py --all
"""

from __future__ import annotations
import argparse
import copy
import sys
import numpy as np
import pandas as pd
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.models import Host, VM
from src.awsp_plus import (
    awsp_plus_policy, build_bucket_index, power_of_k_sample,
    select_best, DEFAULT_THETA, DEFAULT_WEIGHTS, DEFAULT_K,
    DEFAULT_ALPHA, DEFAULT_BETA,
)
from src.simulator import Simulator
from utils.data_loader import DATASET_META, LOADERS

SEEDS = [17, 42, 73, 128, 257]


# ---------------------------------------------------------------------------
# Ablation policies
# ---------------------------------------------------------------------------

def awsp_m1_policy(hosts, vm, *, theta, weights, alpha, beta=DEFAULT_BETA,
                   k=DEFAULT_K, rng, exclude=-1):
    """No M1: sample k hosts uniformly at random (no bucket steering)."""
    feasible = [
        h for h in hosts
        if h.host_id != exclude and h.can_fit(vm.demands, theta)
    ]
    if not feasible:
        return -1
    n = min(k, len(feasible))
    pool_ids = rng.choice(len(feasible), size=n, replace=False)
    pool = [feasible[i] for i in pool_ids]
    best = select_best(pool, vm, theta, weights, alpha, beta)
    return best.host_id if best else -1


def awsp_m12_policy(hosts, vm, *, theta, weights, alpha, beta=DEFAULT_BETA,
                    k=DEFAULT_K, rng, exclude=-1):
    """M1+M2 only: power-of-k sampling with bucket index but random tie-breaking."""
    bucket_index = build_bucket_index(
        [h for h in hosts if h.host_id != exclude]
    )
    max_caps = np.max(np.vstack([h.capacities for h in hosts]), axis=0)
    candidates = power_of_k_sample(
        [h for h in hosts if h.host_id != exclude],
        vm, bucket_index, theta, max_caps, k, rng
    )
    if not candidates:
        feasible = [h for h in hosts
                    if h.host_id != exclude and h.can_fit(vm.demands, theta)]
        if not feasible:
            return -1
        candidates = [feasible[rng.integers(len(feasible))]]
    # Random selection (no M3)
    chosen = candidates[rng.integers(len(candidates))]
    return chosen.host_id


def awsp_m3_policy(hosts, vm, *, theta, weights, alpha, beta=DEFAULT_BETA,
                   k=DEFAULT_K, rng, exclude=-1):
    """M3 only: score ALL feasible hosts — O(|H|), no sampling."""
    feasible = [
        h for h in hosts
        if h.host_id != exclude and h.can_fit(vm.demands, theta)
    ]
    if not feasible:
        return -1
    best = select_best(feasible, vm, theta, weights, alpha, beta)
    return best.host_id if best else -1


ABLATION_POLICIES = {
    "AWSP-M1":  awsp_m1_policy,
    "AWSP-M12": awsp_m12_policy,
    "AWSP-M3":  awsp_m3_policy,
    "AWSP++":   awsp_plus_policy,
}


def build_hosts(dataset: str) -> list:
    meta  = DATASET_META[dataset]
    caps  = meta["capacities"].copy()
    return [Host(host_id=i, capacities=caps.copy())
            for i in range(meta["n_hosts"])]


def run_ablation(dataset: str, seeds: list, n_vms: int = 0):
    results = {name: [] for name in ABLATION_POLICIES}

    for seed in seeds:
        print(f"  seed={seed}", end=" ", flush=True)
        loader = LOADERS[dataset]
        if dataset == "Bitbrains":
            vms, meta = loader(seed=seed)
        else:
            kwargs = {"seed": seed}
            if n_vms > 0:
                kwargs["n_vms"] = n_vms
            vms, meta = loader(**kwargs)

        hosts = build_hosts(dataset)
        for name, policy in ABLATION_POLICIES.items():
            sim = Simulator(
                hosts, policy,
                theta   = DEFAULT_THETA,
                weights = DEFAULT_WEIGHTS,
                alpha   = DEFAULT_ALPHA,
                beta    = DEFAULT_BETA,
                k       = DEFAULT_K,
                seed    = seed,
            )
            r = sim.run(vms, window=meta["window"],
                        dataset=dataset, algorithm=name, seed=seed)
            results[name].append(r)
    print()
    return results


def main():
    parser = argparse.ArgumentParser(description="AWSP++ ablation study")
    parser.add_argument("--dataset",  default="Google",
                        choices=list(DATASET_META.keys()))
    parser.add_argument("--seeds",    nargs="+", type=int, default=SEEDS)
    parser.add_argument("--all",      action="store_true")
    parser.add_argument("--n_vms",    type=int, default=0)
    args = parser.parse_args()

    datasets = list(DATASET_META.keys()) if args.all else [args.dataset]
    rows = []
    for dataset in datasets:
        print(f"\n[Ablation] {dataset}:")
        results = run_ablation(dataset, args.seeds, args.n_vms)
        for name, res_list in results.items():
            vals = np.array([[r.active_hosts, r.energy_kwh,
                              r.weighted_slack, r.sla_rate]
                             for r in res_list])
            row = {
                "variant": name, "dataset": dataset,
                "mean_H":     np.mean(vals[:, 0]),
                "mean_E":     np.mean(vals[:, 1]),
                "mean_slack": np.mean(vals[:, 2]),
                "mean_sla":   np.mean(vals[:, 3]),
            }
            rows.append(row)
            print(f"  {name:10s}: H={row['mean_H']:.0f}, "
                  f"E={row['mean_E']:.2f} kWh, "
                  f"Slack={row['mean_slack']:.2f}, "
                  f"SLA={row['mean_sla']:.2f}%")

    df = pd.DataFrame(rows)
    out = Path("results") / "ablation_table6.csv"
    out.parent.mkdir(exist_ok=True)
    df.to_csv(out, index=False)
    print(f"\nSaved: {out}")


if __name__ == "__main__":
    main()
