# Dataset Download Instructions

AWSP++ is evaluated on three public datasets. This directory is a placeholder.
Place downloaded files here before running `scripts/evaluate.py`.

## Dataset 1: Google Cluster v3

**Paper reference:** Table 2 — 1,287,453 VMs, 24-hour trace, CPU and RAM.

**Download:**
```
https://github.com/google/cluster-data/blob/master/ClusterData2019.md
```
The trace is available as Parquet files on Google Cloud Storage:
```
gs://clusterdata_2019_a/
```
Use the `instance_events` table. Required columns: `time`, `resource_request`
(CPU fraction and RAM fraction). Normalise to host capacity units before use.

Expected file: `data/google_cluster_v3_subset.csv`

**Columns required by data_loader.py:**
```
vm_id, cpu_cores, memory_gb, start_time_s, end_time_s
```

## Dataset 2: Azure Packing 2020

**Paper reference:** Table 2 — 692,144 VMs, 14-day trace, CPU and RAM.

**Download:**
```
https://github.com/Azure/AzurePublicDataset/blob/master/AzurePublicDatasetV2.md
```
Direct URL (Azure Blob):
```
https://azurecloudpublicdataset.blob.core.windows.net/azurepublicdataset/trace_data/
```
Use the `vmtable` CSV. Required columns: `vm id`, `core count`, `memory (gb)`,
`timestamp vm created`, `timestamp vm deleted`.

Expected file: `data/azure_packing_2020_subset.csv`

**Columns required by data_loader.py:**
```
vm_id, cpu_cores, memory_gb, start_time_s, end_time_s
```

## Dataset 3: Bitbrains GWA-T-12

**Paper reference:** Table 2 — 1,750 VMs, 30-day trace, CPU, RAM and BW.

**Download:**
```
http://gwa.ewi.tudelft.nl/datasets/gwa-t-12-bitbrains
```
Two sub-traces: FastStorage and Rnd. Merge both; map `CPU usage [%]` to cores,
`Memory usage [KB]` to GB, and `Network received throughput [KB/s]` to Gb/s.

Expected file: `data/bitbrains_gwat12.csv`

**Columns required by data_loader.py:**
```
vm_id, cpu_cores, memory_gb, bw_gbps, start_time_s, end_time_s
```

## Synthetic Fallback

If none of the CSV files are present, `data_loader.py` automatically falls back
to calibrated synthetic streams (`src/simulator.py`). The synthetic streams
reproduce the statistical properties of each trace (VM size distribution, arrival
patterns, lifetime distribution) and are sufficient for algorithm comparison.
Results from the synthetic streams differ numerically from the CloudSim 7 runs
reported in the paper — see README.md for details.

## Host Configuration

All experiments use homogeneous hosts with the following hardware profile
(Table 1 of the paper):

| Resource | Capacity   | P_idle | P_max |
|----------|-----------|--------|-------|
| CPU      | 16 cores   | 86 W   | 287 W |
| RAM      | 192 GB     |        |       |
| BW       | 25 Gb/s    |        |       |

Fleet size: 12,500 hosts (Google), 8,000 hosts (Azure), 500 hosts (Bitbrains).
