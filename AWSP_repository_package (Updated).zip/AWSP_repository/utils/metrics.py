"""
Metric aggregation utilities for AWSP++ experiments.
"""

from __future__ import annotations
import numpy as np
from typing import List, Dict, Any


def compute_metrics(results: List) -> Dict[str, Any]:
    """
    Aggregate a list of PlacementResult objects (one per seed).

    Returns a dict with mean ± std for each metric field.
    """
    if not results:
        return {}

    fields = [
        "active_hosts", "energy_kwh", "weighted_slack",
        "sla_rate", "migration_count", "avg_decision_ms",
    ]
    agg = {}
    for f in fields:
        vals = np.array([getattr(r, f) for r in results], dtype=float)
        agg[f"mean_{f}"] = float(np.mean(vals))
        agg[f"std_{f}"]  = float(np.std(vals, ddof=1))
        agg[f"vals_{f}"] = vals.tolist()
    return agg


def aggregate_seeds(results_dict: Dict) -> Dict:
    """
    results_dict : {algorithm: {dataset: [PlacementResult, ...]}}
    Returns nested dict with aggregated stats.
    """
    out = {}
    for algo, ds_map in results_dict.items():
        out[algo] = {}
        for dataset, result_list in ds_map.items():
            out[algo][dataset] = compute_metrics(result_list)
    return out


def pct_improvement(baseline_val: float, awsp_val: float,
                    lower_is_better: bool = True) -> float:
    """Percentage improvement of AWSP++ over baseline."""
    if abs(baseline_val) < 1e-12:
        return 0.0
    if lower_is_better:
        return 100.0 * (baseline_val - awsp_val) / baseline_val
    else:
        return 100.0 * (awsp_val - baseline_val) / baseline_val


def format_table5_row(algo: str, dataset: str, agg: Dict) -> str:
    """Format one row for Table 5 reproduction."""
    return (
        f"{algo:15s} | {dataset:10s} | "
        f"H={agg.get('mean_active_hosts', 0):.0f} | "
        f"E={agg.get('mean_energy_kwh', 0):.2f} kWh | "
        f"Slack={agg.get('mean_weighted_slack', 0):.2f} | "
        f"SLA={agg.get('mean_sla_rate', 0):.2f}% | "
        f"Mig={agg.get('mean_migration_count', 0):.0f} | "
        f"t_d={agg.get('mean_avg_decision_ms', 0):.2f}ms"
    )
