"""
Statistical significance tests for VM placement comparisons.

Implements:
  - Paired two-sided t-test across 5 seeds
  - Cohen's d (paired formulation): d = mean_diff / std_diff
  - Bonferroni correction for 30 simultaneous comparisons:
    alpha_corrected = 0.05 / 30 = 1.667e-3

Paper reference: Section V-D, Table 8.
"""

from __future__ import annotations
import numpy as np
from scipy import stats
from typing import List, Tuple, Dict


BONFERRONI_N_TESTS = 30
FAMILY_ALPHA       = 0.05
BONFERRONI_ALPHA   = FAMILY_ALPHA / BONFERRONI_N_TESTS   # 1.667e-3


def cohens_d_paired(x: np.ndarray, y: np.ndarray) -> float:
    """
    Cohen's d for paired samples.

    d = mean(x - y) / std(x - y, ddof=1)

    Parameters
    ----------
    x : per-seed values for method A (AWSP++)
    y : per-seed values for method B (baseline)

    Returns
    -------
    Cohen's d  (positive => x < y, i.e. AWSP++ is better when minimising)
    """
    diff = np.asarray(x, dtype=float) - np.asarray(y, dtype=float)
    std_diff = np.std(diff, ddof=1)
    if std_diff < 1e-15:
        return 0.0
    return float(np.mean(diff) / std_diff)


def paired_ttest_bonferroni(
    awsp_values: np.ndarray,
    baseline_values: np.ndarray,
    metric_name: str = "",
    baseline_name: str = "",
    dataset_name: str = "",
) -> Dict:
    """
    Paired two-sided t-test with Bonferroni correction.

    Parameters
    ----------
    awsp_values     : shape (5,) — per-seed AWSP++ metric values
    baseline_values : shape (5,) — per-seed baseline metric values
    metric_name     : label for reporting
    baseline_name   : label for reporting
    dataset_name    : label for reporting

    Returns
    -------
    dict with keys: t_stat, p_value, p_bonferroni_threshold,
                    significant, cohens_d, mean_diff, std_diff
    """
    awsp = np.asarray(awsp_values, dtype=float)
    base = np.asarray(baseline_values, dtype=float)

    t_stat, p_value = stats.ttest_rel(awsp, base, alternative='two-sided')
    d = cohens_d_paired(awsp, base)
    diff = awsp - base

    return {
        "metric":                metric_name,
        "baseline":              baseline_name,
        "dataset":               dataset_name,
        "t_stat":                float(t_stat),
        "p_value":               float(p_value),
        "p_bonferroni_threshold": BONFERRONI_ALPHA,
        "significant":           bool(p_value < BONFERRONI_ALPHA),
        "cohens_d":              float(d),
        "mean_diff":             float(np.mean(diff)),
        "std_diff":              float(np.std(diff, ddof=1)),
        "n_seeds":               len(awsp),
    }


def run_all_tests(results_by_seed: Dict) -> List[Dict]:
    """
    Run the full 30-comparison battery from Table 8.

    Parameters
    ----------
    results_by_seed : {algorithm: {dataset: {seed: PlacementResult}}}

    Returns
    -------
    list of test result dicts (one per comparison)
    """
    from ..src.models import PlacementResult  # avoid circular at module level

    SEEDS     = [17, 42, 73, 128, 257]
    DATASETS  = ["Google", "Azure", "Bitbrains"]
    BASELINES = ["PABFD", "GRVMP", "LBMBP", "Entropy-VMP", "HUNTER", "K-RL-VMP"]
    METRICS   = {
        "energy_kwh":      "Energy (kWh)",
        "active_hosts":    "Active Hosts",
        "sla_rate":        "SLA Rate (%)",
        "migration_count": "Migrations",
    }

    tests = []
    for dataset in DATASETS:
        for baseline_name in BASELINES:
            for attr, label in METRICS.items():
                try:
                    awsp_vals = np.array([
                        getattr(results_by_seed["AWSP++"][dataset][s], attr)
                        for s in SEEDS
                    ])
                    base_vals = np.array([
                        getattr(results_by_seed[baseline_name][dataset][s], attr)
                        for s in SEEDS
                    ])
                    r = paired_ttest_bonferroni(
                        awsp_vals, base_vals,
                        metric_name=label,
                        baseline_name=baseline_name,
                        dataset_name=dataset,
                    )
                    tests.append(r)
                except KeyError:
                    pass
    return tests
