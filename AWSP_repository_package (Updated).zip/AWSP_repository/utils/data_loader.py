"""
Dataset loaders for AWSP++ experiments.

Supported datasets (Table 2 in the paper):
  - Google Cluster v3      (1,287,453 VMs, CPU+RAM, 24h window)
  - Azure Packing 2020     (692,144 VMs, CPU+RAM, 14-day window)
  - Bitbrains GWA-T-12     (1,750 VMs, CPU+RAM+BW, 30-day window)

If the real trace files are not available, the loaders fall back to
calibrated synthetic streams (src/simulator.py).

Real data download instructions: see data/README.md
"""

from __future__ import annotations
import os
import numpy as np
from pathlib import Path
from typing import List, Tuple

from ..src.models import VM, N_RES
from ..src.simulator import (
    make_vm,
    synthetic_google_stream,
    synthetic_azure_stream,
    synthetic_bitbrains_stream,
)


DATA_DIR = Path(__file__).resolve().parent.parent / "data"

# ---------------------------------------------------------------------------
# Dataset metadata (Table 2)
# ---------------------------------------------------------------------------
DATASET_META = {
    "Google": {
        "n_vms":    1_287_453,
        "n_hosts":  12_500,
        "window":   86_400.0,       # 24 hours
        "resources": ["cpu", "ram"],
        "capacities": np.array([16.0, 192.0, 0.0]),
        "file":     "google_cluster_v3_subset.csv",
    },
    "Azure": {
        "n_vms":    692_144,
        "n_hosts":  8_000,
        "window":   1_209_600.0,    # 14 days
        "resources": ["cpu", "ram"],
        "capacities": np.array([16.0, 192.0, 0.0]),
        "file":     "azure_packing_2020_subset.csv",
    },
    "Bitbrains": {
        "n_vms":    1_750,
        "n_hosts":  500,
        "window":   2_592_000.0,    # 30 days
        "resources": ["cpu", "ram", "bw"],
        "capacities": np.array([16.0, 192.0, 25.0]),
        "file":     "bitbrains_gwat12.csv",
    },
}


def load_google(seed: int = 42, n_vms: int = 50_000) -> Tuple[List[VM], dict]:
    """
    Load (subset of) Google Cluster v3 trace.
    Falls back to synthetic stream if CSV is not present.

    Returns (vm_list, meta_dict)
    """
    csv_path = DATA_DIR / DATASET_META["Google"]["file"]
    if csv_path.exists():
        return _load_csv_google(csv_path, seed, n_vms), DATASET_META["Google"]
    # Synthetic fallback
    meta = DATASET_META["Google"]
    vms  = synthetic_google_stream(n_vms, meta["n_hosts"], seed, meta["window"])
    return vms, meta


def load_azure(seed: int = 42, n_vms: int = 30_000) -> Tuple[List[VM], dict]:
    """Load Azure Packing 2020 trace or synthetic fallback."""
    csv_path = DATA_DIR / DATASET_META["Azure"]["file"]
    if csv_path.exists():
        return _load_csv_azure(csv_path, seed, n_vms), DATASET_META["Azure"]
    meta = DATASET_META["Azure"]
    vms  = synthetic_azure_stream(n_vms, meta["n_hosts"], seed, meta["window"])
    return vms, meta


def load_bitbrains(seed: int = 42) -> Tuple[List[VM], dict]:
    """Load Bitbrains GWA-T-12 trace or synthetic fallback."""
    csv_path = DATA_DIR / DATASET_META["Bitbrains"]["file"]
    if csv_path.exists():
        return _load_csv_bitbrains(csv_path, seed), DATASET_META["Bitbrains"]
    meta = DATASET_META["Bitbrains"]
    vms  = synthetic_bitbrains_stream(meta["n_vms"], seed, meta["window"])
    return vms, meta


# ---------------------------------------------------------------------------
# CSV parsers (for real data, adjust column names to match downloaded files)
# ---------------------------------------------------------------------------

def _load_csv_google(path: Path, seed: int, n_vms: int) -> List[VM]:
    """
    Expected CSV columns (Google Cluster v3):
      vm_id, cpu_cores, memory_gb, start_time_s, end_time_s
    """
    import pandas as pd
    df = pd.read_csv(path, nrows=n_vms)
    rng = np.random.default_rng(seed)
    vms = []
    for idx, row in df.iterrows():
        demands  = np.array([row["cpu_cores"], row["memory_gb"], 0.0])
        lifetime = max(row["end_time_s"] - row["start_time_s"], 1.0)
        vm = make_vm(int(row["vm_id"]), demands,
                     float(row["start_time_s"]), lifetime)
        vms.append(vm)
    return vms


def _load_csv_azure(path: Path, seed: int, n_vms: int) -> List[VM]:
    """
    Expected CSV columns (Azure Packing 2020):
      vm_id, cpu_cores, memory_gb, start_time_s, end_time_s
    """
    import pandas as pd
    df = pd.read_csv(path, nrows=n_vms)
    vms = []
    for idx, row in df.iterrows():
        demands  = np.array([row["cpu_cores"], row["memory_gb"], 0.0])
        lifetime = max(row["end_time_s"] - row["start_time_s"], 1.0)
        vm = make_vm(int(row["vm_id"]), demands,
                     float(row["start_time_s"]), lifetime)
        vms.append(vm)
    return vms


def _load_csv_bitbrains(path: Path, seed: int) -> List[VM]:
    """
    Expected CSV columns (Bitbrains GWA-T-12):
      vm_id, cpu_cores, memory_gb, bw_gbps, start_time_s, end_time_s
    """
    import pandas as pd
    df = pd.read_csv(path)
    vms = []
    for idx, row in df.iterrows():
        demands = np.array([
            row.get("cpu_cores", 0),
            row.get("memory_gb", 0),
            row.get("bw_gbps", 0),
        ], dtype=float)
        lifetime = max(row["end_time_s"] - row["start_time_s"], 1.0)
        vm = make_vm(int(row["vm_id"]), demands,
                     float(row["start_time_s"]), lifetime)
        vms.append(vm)
    return vms


LOADERS = {
    "Google":    load_google,
    "Azure":     load_azure,
    "Bitbrains": load_bitbrains,
}
