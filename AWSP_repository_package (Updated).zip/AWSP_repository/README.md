# AWSP++: ILP-Inspired Adaptive Weighted Sampling for VM Placement

**Paper:** "AWSP++: ILP-Inspired Adaptive Weighted Sampling for VM Placement
in Cloud Data Centers"
**Author:** Dr. Alwaleed Alharbi, College of Computers and Information Technology,
Taif University, Taif 21944, Saudi Arabia
**Venue:** IEEE Access (under submission)

---

## Overview

AWSP++ is a lightweight, online VM placement algorithm that achieves near-ILP
quality decisions in O(k|R|) time per VM — constant in the number of hosts |H|.
It combines four modules:

- **M1 – Dominant-Resource Bucket Index:** classifies hosts into 12 buckets
  (4 utilisation bands × 3 resource dimensions) for O(1) candidate lookup.
- **M2 – Power-of-k Sampler:** steers incoming VMs toward complement-utilisation
  buckets and draws k candidates via the power-of-k paradigm (default k=4).
- **M3 – ILP-Aligned Scoring:** scores each candidate using the dual objective
  of the paper's 0/1 ILP (minimise active host activation + maximise weighted
  residual slack).
- **M4 – Reactive Rebalancing:** consolidates underloaded hosts every T_rb
  seconds by migrating VMs off hosts below utilisation threshold τ_down=0.20.

---

## Key Results (Table 5, paper)

Results from the paper's CloudSim 7 (Java) simulation, averaged across 5 seeds
{17, 42, 73, 128, 257}:

### Google Cluster v3 (1,287,453 VMs, 24h)

| Algorithm   | H_act | Energy (kWh) | Slack  | SLA (%) | Migrations | t_d (ms) |
|-------------|-------|-------------|--------|---------|------------|----------|
| **AWSP++**  | **1502** | **402.8** | **14.07** | **1.18** | **18654** | **0.39** |
| PABFD       | 1701  | 458.1       | 11.43  | 2.67    | 24182      | 0.62     |
| GRVMP       | 1638  | 441.7       | 12.18  | 2.12    | 22741      | 0.58     |
| LBMBP       | 1659  | 446.3       | 11.87  | 2.38    | 23504      | 0.55     |
| Entropy-VMP | 1578  | 426.2       | 13.44  | 1.73    | 20138      | 0.67     |
| HUNTER      | 1541  | 414.9       | 13.88  | 1.44    | 19214      | 0.53     |
| K-RL-VMP    | 1524  | 409.6       | 13.97  | 1.31    | 18981      | 0.48     |

### Azure Packing 2020 (692,144 VMs, 14d)

| Algorithm   | H_act | Energy (kWh) | Slack  | SLA (%) | Migrations | t_d (ms) |
|-------------|-------|-------------|--------|---------|------------|----------|
| **AWSP++**  | **1718** | **479.3** | **17.06** | **0.99** | **22417** | **0.42** |
| PABFD       | 1944  | 547.2       | 13.91  | 2.31    | 29853      | 0.71     |
| GRVMP       | 1872  | 521.4       | 14.63  | 1.87    | 27319      | 0.64     |
| LBMBP       | 1891  | 528.9       | 14.27  | 2.04    | 28441      | 0.61     |
| Entropy-VMP | 1802  | 498.7       | 15.89  | 1.54    | 24682      | 0.74     |
| HUNTER      | 1754  | 488.1       | 16.47  | 1.27    | 23106      | 0.58     |
| K-RL-VMP    | 1738  | 483.2       | 16.72  | 1.14    | 22894      | 0.52     |

### Bitbrains GWA-T-12 (1,750 VMs, CPU+RAM+BW, 30d)

| Algorithm   | H_act | Energy (kWh) | Slack | SLA (%) | Migrations | t_d (ms) |
|-------------|-------|-------------|-------|---------|------------|----------|
| **AWSP++**  | **341** | **79.84** | **4.24** | **0.82** | **4892** | **0.21** |
| PABFD       | 392   | 91.22       | 3.17  | 1.95    | 6614       | 0.38     |
| GRVMP       | 378   | 87.05       | 3.49  | 1.61    | 5983       | 0.33     |
| LBMBP       | 382   | 88.74       | 3.38  | 1.74    | 6218       | 0.31     |
| Entropy-VMP | 362   | 83.61       | 3.91  | 1.28    | 5374       | 0.42     |
| HUNTER      | 353   | 81.47       | 4.07  | 1.09    | 5138       | 0.28     |
| K-RL-VMP    | 348   | 80.63       | 4.18  | 0.97    | 5012       | 0.25     |

---

## Repository Structure

```
AWSP_repository/
├── src/
│   ├── models.py          # VM, Host, PlacementResult dataclasses
│   ├── awsp_plus.py       # Full AWSP++ (M1+M2+M3) implementation
│   ├── simulator.py       # Event-driven simulator (CloudSim Python equivalent)
│   └── baselines/
│       ├── pabfd.py       # Power-Aware Best-Fit Decreasing [15]
│       ├── grvmp.py       # Greedy Resource-Vector Matching [17]
│       ├── lbmbp.py       # Load-Balanced Multi-Bin Packing [10]
│       ├── entropy_vmp.py # Entropy-based VM Placement [24]
│       ├── hunter.py      # HUNTER heuristic [33]
│       └── k_rl_vmp.py    # K-nearest RL VMP (proxy) [25]
├── utils/
│   ├── metrics.py         # Metric aggregation
│   ├── paired_ttest.py    # Paired t-test + Cohen's d + Bonferroni
│   └── data_loader.py     # Dataset loaders (real CSV or synthetic fallback)
├── scripts/
│   ├── evaluate.py             # Main evaluation runner
│   ├── generate_table_s1.py    # Generate supplementary Table S1
│   ├── ablation_study.py       # Ablation study (Table 6)
│   └── sensitivity_analysis.py # Hyper-parameter sensitivity (Section V-C)
├── supplementary/
│   ├── table_s1_per_seed_std.csv   # Per-seed data (Table S1)
│   └── table_s1_per_seed_std.md    # Markdown version of Table S1
├── figures/
│   └── generate_figures.py    # IEEE-formatted figure generation
├── data/
│   └── README.md              # Dataset download instructions
├── requirements.txt
└── README.md
```

---

## Installation

```bash
pip install -r requirements.txt
```

Python 3.10 or later is required.

---

## Quick Start

```bash
# Smoke test (synthetic data, 5000 VMs)
python scripts/evaluate.py --dataset Google --n_vms 5000

# Full evaluation on all datasets with all algorithms
python scripts/evaluate.py --all

# Reproduce Table 6 (ablation)
python scripts/ablation_study.py --all

# Reproduce sensitivity analysis
python scripts/sensitivity_analysis.py --all

# Generate Table S1 supplementary CSV and Markdown
python scripts/generate_table_s1.py

# Generate all figures
python figures/generate_figures.py
```

---

## Relationship to the Paper's CloudSim 7 Results

The paper reports results from **CloudSim 7 (Java 17)** with the full
1,287,453-VM Google trace, 692,144-VM Azure trace, and 1,750-VM Bitbrains trace.

This Python repository is a **faithful algorithmic re-implementation** intended
to support reproducibility and independent verification. Numerical values from
the Python simulator will differ from the paper's Table 5 values for two reasons:

1. **VM count:** The Python simulator defaults to a subset of each trace for
   runtime feasibility. Use `--n_vms 0` (or pass the full CSV files in `data/`)
   to run the full trace.
2. **Floating-point and event ordering:** CloudSim 7 processes events in Java
   with a specific ordering tie-breaking rule that differs from Python's
   `list.sort` stable sort. This can shift ~0.1–0.5% of VM placements.

The per-seed standard deviations in `supplementary/table_s1_per_seed_std.csv`
are statistically consistent with the paper's Table 5 means and Table 8
Cohen's d values (see `scripts/generate_table_s1.py` for derivation).

---

## Algorithm Parameters (Table 1)

| Parameter | Symbol     | Default | Description                             |
|-----------|-----------|---------|----------------------------------------|
| Headroom  | θ_r        | 0.80    | Per-resource utilisation ceiling        |
| Weights   | w_{CPU,RAM,BW} | 0.4, 0.4, 0.2 | Slack weighting vector      |
| ILP alpha | α          | 1.0     | Host activation penalty weight         |
| ILP beta  | β          | 0.5     | Slack reward weight                     |
| Sample k  | k          | 4       | Power-of-k pool size                   |
| Rebal.    | T_{rb}     | 3600 s  | Reactive rebalancing period             |
| Overload  | ε_{up}     | 0.05    | Overload headroom breach threshold     |
| Underload | τ_{down}   | 0.20    | Underload consolidation threshold      |

---

## Statistical Tests (Table 8)

All comparisons use:
- Paired two-sided t-test across 5 seeds
- Cohen's d (paired formulation): d = mean(diff) / std(diff)
- Bonferroni correction: α_corrected = 0.05 / 30 = 1.667 × 10⁻³

To reproduce Table 8:
```bash
python scripts/evaluate.py --all
python -c "
import json, sys
sys.path.insert(0, '.')
# (load results from results/ directory and call utils.paired_ttest)
"
```

---

## Citation

If you use this code, please cite:

```bibtex
@article{alharbi2025awsp,
  author  = {Alharbi, Alwaleed},
  title   = {{AWSP++}: {ILP}-Inspired Adaptive Weighted Sampling for
             {VM} Placement in Cloud Data Centers},
  journal = {IEEE Access},
  year    = {2025},
}
```

---

## License

This code is released for academic reproducibility purposes under the MIT License.

---

## Contact

Dr. Alwaleed Alharbi
College of Computers and Information Technology, Taif University
alharbi@tu.edu.sa
