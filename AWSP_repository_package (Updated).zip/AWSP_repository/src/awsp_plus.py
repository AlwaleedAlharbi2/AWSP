"""
AWSP++: ILP-Inspired Adaptive Weighted Sampling for VM Placement.

Implements all four modules from the paper (Algorithm 1):
  M1 – Dominant-Resource Bucket Index
  M2 – Power-of-k Sampler
  M3 – ILP-Aligned Scoring
  M4 – Reactive Rebalancing (called from Simulator._rebalance)

Per-VM decision complexity: O(k * |R|)   (constant in |H|)

Paper parameters (defaults):
  theta_r = 0.80  for all r          (headroom factor, Table 1)
  w = (0.4, 0.4, 0.2)               (resource weights, Table 1)
  alpha = 1.0,  beta = 0.5          (ILP objective weights, eq. 2)
  k = 4                              (sampling pool size, Table 1)
  B = 4 bands  x  R = 3 resources = 12 buckets
  band edges: 0.0, 0.25, 0.50, 0.75, 1.0
"""

from __future__ import annotations
import numpy as np
from typing import List, Optional

from .models import Host, VM, N_RES

# ---------------------------------------------------------------------------
# Constants (Table 1)
# ---------------------------------------------------------------------------
DEFAULT_THETA   = np.array([0.80, 0.80, 0.80])
DEFAULT_WEIGHTS = np.array([0.40, 0.40, 0.20])
DEFAULT_K       = 4
DEFAULT_ALPHA   = 1.0
DEFAULT_BETA    = 0.50

BAND_EDGES = np.array([0.0, 0.25, 0.50, 0.75, 1.0])   # B=4 bands
N_BANDS    = len(BAND_EDGES) - 1                        # 4


# ---------------------------------------------------------------------------
# M1: Dominant-Resource Bucket Index
# ---------------------------------------------------------------------------

def _bucket_index(rho: np.ndarray) -> int:
    """
    Compute bucket index b(j) for host j.

    b(j) = r*(j) * B + band(rho_{r*(j),j})    (eq. 13-14)

    where r*(j) = argmax_r rho_r(j) (dominant resource) and
    band(x) = floor(x / 0.25) clamped to [0, B-1].

    Returns an integer in [0, R*B-1] = [0, 11].
    """
    dom_r = int(np.argmax(rho))
    dom_rho = float(rho[dom_r])
    band = min(int(dom_rho / 0.25), N_BANDS - 1)
    return dom_r * N_BANDS + band


def build_bucket_index(hosts: List[Host]) -> dict:
    """
    Build a mapping  bucket_id -> [host_id, ...]  for all active hosts.

    This is O(|H|) and called once per placement decision in the
    simulation (we rebuild lazily; a production system would maintain
    the index incrementally).
    """
    index: dict = {}
    for host in hosts:
        if not host.is_active:
            continue
        rho = host.rho()
        bid = _bucket_index(rho)
        index.setdefault(bid, []).append(host.host_id)
    return index


# ---------------------------------------------------------------------------
# M2: Power-of-k Sampler
# ---------------------------------------------------------------------------

def _target_bucket(vm: VM, theta: np.ndarray, max_caps: np.ndarray) -> int:
    """
    Map incoming VM to target bucket b*(v).

    The dominant resource of the VM is computed from normalised demand
    (eq. 15), then the target band is the complement band to fill the
    dominant dimension without overloading (eq. 16).

    We target the bucket in band 0 (low utilisation) for the dominant
    resource dimension, so we steer the VM toward hosts with room.
    """
    dom_r = vm.dominant_resource(theta, max_caps)
    # Target the lowest utilisation band of the VM's dominant dimension
    # (Section IV-B, bucket steering heuristic)
    return dom_r * N_BANDS + 0   # band 0 = [0, 0.25)


def power_of_k_sample(hosts: List[Host], vm: VM,
                      bucket_index: dict,
                      theta: np.ndarray, max_caps: np.ndarray,
                      k: int, rng: np.random.Generator) -> List[Host]:
    """
    Power-of-k sampling (Algorithm 1, M2).

    1. Compute target bucket b*(v) for the VM.
    2. Collect candidate list C from b*(v); if |C| < k, expand to
       adjacent buckets until |C| >= k or all buckets exhausted.
    3. Draw k candidates uniformly at random (without replacement)
       from C, filtered to feasible hosts (can_fit).

    Returns up to k feasible Host objects.
    """
    target_b = _target_bucket(vm, theta, max_caps)
    dom_r    = vm.dominant_resource(theta, max_caps)

    # Ordered bucket search: target bucket first, then neighbours by distance
    all_bids = list(range(N_RES * N_BANDS))
    all_bids.sort(key=lambda b: abs(b - target_b))

    candidate_ids: List[int] = []
    host_map = {h.host_id: h for h in hosts}

    for bid in all_bids:
        for hid in bucket_index.get(bid, []):
            h = host_map.get(hid)
            if h is not None and h.can_fit(vm.demands, theta):
                candidate_ids.append(hid)
        if len(candidate_ids) >= k * 4:   # enough; over-sample for safety
            break

    if not candidate_ids:
        # Fallback: scan all active, feasible hosts
        candidate_ids = [
            h.host_id for h in hosts
            if h.is_active and h.can_fit(vm.demands, theta)
        ]

    if not candidate_ids:
        return []   # no feasible host exists; will trigger SLA violation

    # Sample min(k, |candidates|) without replacement
    n_pick = min(k, len(candidate_ids))
    chosen_ids = rng.choice(candidate_ids, size=n_pick, replace=False)
    return [host_map[hid] for hid in chosen_ids]


# ---------------------------------------------------------------------------
# M3: ILP-Aligned Scoring
# ---------------------------------------------------------------------------

def ilp_score(host: Host, vm: VM,
              theta: np.ndarray, weights: np.ndarray,
              alpha: float, beta: float) -> float:
    """
    ILP-inspired placement score for (host, vm) pair (eq. 17).

    score(j, v) = -alpha * activation_cost(j) * new_j
                 + beta  * sum_r w_r * s_jr_after

    where:
      new_j           = 1 if host is currently inactive (would be activated)
      s_jr_after      = theta_r * C_jr - (U_jr + d_rv)  residual slack after
                        placement, clipped at 0

    Higher score is better. We negate the activation cost (alpha term)
    to penalise turning on a new host, matching the ILP minimisation objective.
    """
    activation_penalty = alpha * host.activation_cost * (0 if host.is_active else 1)
    post_util = host.utilization + vm.demands
    residual  = np.maximum(theta * host.capacities - post_util, 0.0)
    slack_gain = float(np.dot(weights, residual))
    return -activation_penalty + beta * slack_gain


def select_best(candidates: List[Host], vm: VM,
                theta: np.ndarray, weights: np.ndarray,
                alpha: float, beta: float) -> Optional[Host]:
    """Return the highest-scoring feasible host from the candidate list."""
    if not candidates:
        return None
    return max(candidates,
               key=lambda h: ilp_score(h, vm, theta, weights, alpha, beta))


# ---------------------------------------------------------------------------
# Public placement policy (called by Simulator)
# ---------------------------------------------------------------------------

def awsp_plus_policy(hosts: List[Host], vm: VM, *,
                     theta: np.ndarray = DEFAULT_THETA,
                     weights: np.ndarray = DEFAULT_WEIGHTS,
                     alpha: float  = DEFAULT_ALPHA,
                     beta: float   = DEFAULT_BETA,
                     k: int        = DEFAULT_K,
                     rng: np.random.Generator,
                     exclude: int  = -1) -> int:
    """
    Full AWSP++ placement decision for one VM.

    Returns the host_id of the selected host, or -1 if no feasible host
    exists (triggering a SLA violation in the simulator).

    Parameters
    ----------
    hosts   : current list of all Host objects
    vm      : arriving VM
    theta   : headroom vector, shape (N_RES,)
    weights : resource weights, shape (N_RES,)
    alpha   : ILP activation weight
    beta    : ILP slack weight
    k       : power-of-k pool size
    rng     : numpy random Generator (for reproducibility)
    exclude : host_id to skip (used during rebalancing migrations)
    """
    active_hosts = [h for h in hosts if h.host_id != exclude]

    # M1: build bucket index
    bucket_index = build_bucket_index(active_hosts)

    # M1 also considers inactive hosts as potential activation targets
    # (bucket index only covers active hosts; inactive hosts get bucket 0)
    inactive_feasible = [
        h for h in hosts
        if not h.is_active
        and h.host_id != exclude
        and h.can_fit(vm.demands, theta)
    ]

    # M2: power-of-k sample from active buckets
    max_caps = np.max(
        np.vstack([h.capacities for h in hosts]), axis=0
    ) if hosts else np.ones(N_RES)
    candidates = power_of_k_sample(
        active_hosts, vm, bucket_index,
        theta, max_caps, k, rng
    )

    # Also include up to k//2 inactive hosts as candidates
    # (to allow host activation when consolidation is beneficial)
    if inactive_feasible:
        n_inactive = max(1, k // 2)
        inactive_sample = inactive_feasible[:n_inactive]
        candidates = candidates + inactive_sample

    if not candidates:
        return -1

    # M3: ILP-aligned scoring → pick best
    best = select_best(candidates, vm, theta, weights, alpha, beta)
    return best.host_id if best is not None else -1
