"""
Data models for AWSP++ simulation.
VM, Host, and placement-state containers.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional
import numpy as np

# Resource indices
CPU, RAM, BW = 0, 1, 2
RESOURCE_NAMES = ['cpu', 'ram', 'bw']
N_RES = 3

# Default host hardware (Intel Xeon Gold 6242)
DEFAULT_CAPACITIES = np.array([16.0, 192.0, 25.0])   # cores, GB, Gb/s
P_IDLE  = 86.0   # Watts
P_MAX   = 287.0  # Watts


@dataclass
class VM:
    """Virtual machine with resource demands and lifetime."""
    vm_id:        int
    demands:      np.ndarray        # shape (N_RES,): cpu_cores, ram_gb, bw_gbps
    lifetime:     float             # seconds
    arrival_time: float             # simulation time of arrival
    memory_mb:    float = 4096.0    # for migration energy estimate

    # State (set by simulator)
    host_id:       int   = -1
    departure_time: float = 0.0

    @property
    def dominant_resource_raw(self) -> int:
        """Index of resource dimension with largest absolute demand."""
        return int(np.argmax(self.demands))

    def dominant_resource(self, theta: np.ndarray,
                          max_caps: np.ndarray) -> int:
        """Dominant resource: argmax of normalised demand fraction (eq. 15)."""
        norm = self.demands / (theta * max_caps + 1e-12)
        return int(np.argmax(norm))


@dataclass
class Host:
    """Physical host with capacity, power model and runtime state."""
    host_id:          int
    capacities:       np.ndarray    # shape (N_RES,)
    p_idle:           float = P_IDLE
    p_max:            float = P_MAX
    activation_cost:  float = 1.0   # proxy for a_j in the ILP

    # Runtime state (mutated by simulator)
    utilization:   np.ndarray = field(default_factory=lambda: np.zeros(N_RES))
    vms:           List[int]  = field(default_factory=list)
    is_active:     bool       = False

    # -----------------------------------------------------------------
    def residual_slack(self, theta: np.ndarray) -> np.ndarray:
        """s_jr = theta_r * C_jr - U_jr  (eq. 4), clipped to >=0."""
        return np.maximum(theta * self.capacities - self.utilization, 0.0)

    def rho(self) -> np.ndarray:
        """Per-resource utilisation ratio rho_jr = U_jr / C_jr."""
        return self.utilization / (self.capacities + 1e-12)

    def dominant_resource(self) -> int:
        """r*(j) = argmax_r rho_jr  (eq. 13)."""
        return int(np.argmax(self.rho()))

    def power(self) -> float:
        """Linear power model (eq. 1): Phi(U) = P_idle + (P_max-P_idle)*rho_CPU."""
        if not self.is_active:
            return 0.0
        rho_cpu = self.utilization[CPU] / (self.capacities[CPU] + 1e-12)
        return self.p_idle + (self.p_max - self.p_idle) * rho_cpu

    def can_fit(self, demands: np.ndarray, theta: np.ndarray) -> bool:
        """True iff placing demands on this host keeps every resource within headroom."""
        return bool(np.all(self.utilization + demands <= theta * self.capacities))

    def weighted_slack(self, theta: np.ndarray, weights: np.ndarray) -> float:
        """sum_r w_r * s_jr (used in scoring)."""
        return float(np.dot(weights, self.residual_slack(theta)))

    # -----------------------------------------------------------------
    def place(self, vm: VM) -> None:
        self.utilization += vm.demands
        self.vms.append(vm.vm_id)
        self.is_active = True

    def remove(self, vm: VM) -> None:
        self.utilization -= vm.demands
        self.utilization = np.maximum(self.utilization, 0.0)
        self.vms.remove(vm.vm_id)
        if not self.vms:
            self.is_active = False

    def __hash__(self):
        return hash(self.host_id)


@dataclass
class PlacementResult:
    """Metrics collected after a full simulation run."""
    algorithm:       str
    dataset:         str
    seed:            int
    active_hosts:    int
    energy_kwh:      float
    weighted_slack:  float
    sla_rate:        float          # fraction [0,1] (multiply by 100 for %)
    migration_count: int
    avg_decision_ms: float
