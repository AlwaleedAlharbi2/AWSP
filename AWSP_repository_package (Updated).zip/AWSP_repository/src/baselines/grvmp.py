"""
GRVMP – Greedy Resource-Vector Matching Placement [17].

Algorithm:
  Cosine similarity between the VM demand vector and the host residual
  capacity vector. The host maximising cosine similarity is selected,
  provided it satisfies the headroom constraint.
  If no active host fits, the inactive host with maximum total capacity
  is activated.
"""

from __future__ import annotations
import numpy as np
from typing import List

from ..models import Host, VM, N_RES


def _cosine_sim(vm: VM, host: Host, theta: np.ndarray) -> float:
    slack = host.residual_slack(theta)
    denom = (np.linalg.norm(vm.demands) * np.linalg.norm(slack)) + 1e-12
    return float(np.dot(vm.demands, slack)) / denom


def grvmp_policy(hosts: List[Host], vm: VM, *,
                 theta: np.ndarray,
                 weights: np.ndarray,
                 alpha: float,
                 k: int,
                 rng: np.random.Generator,
                 exclude: int = -1) -> int:
    """GRVMP placement policy. Returns host_id or -1."""
    feasible = [
        h for h in hosts
        if h.host_id != exclude and h.can_fit(vm.demands, theta)
    ]
    if not feasible:
        return -1

    best = max(feasible, key=lambda h: _cosine_sim(vm, h, theta))
    return best.host_id
