"""
LBMBP – Load-Balanced Multiple Bin Packing [10].

Algorithm:
  Multi-resource extension of Best-Fit that minimises the
  maximum per-resource utilisation ratio after placement.
  Targets load balance across resources on the selected host.
"""

from __future__ import annotations
import numpy as np
from typing import List

from ..models import Host, VM, N_RES


def _max_rho_after(host: Host, vm: VM) -> float:
    """Maximum per-resource utilisation ratio after placing vm on host."""
    post_util = host.utilization + vm.demands
    ratios = post_util / (host.capacities + 1e-12)
    return float(np.max(ratios))


def lbmbp_policy(hosts: List[Host], vm: VM, *,
                 theta: np.ndarray,
                 weights: np.ndarray,
                 alpha: float,
                 k: int,
                 rng: np.random.Generator,
                 exclude: int = -1) -> int:
    """LBMBP placement policy. Returns host_id or -1."""
    feasible = [
        h for h in hosts
        if h.host_id != exclude and h.can_fit(vm.demands, theta)
    ]
    if not feasible:
        return -1

    best = min(feasible, key=lambda h: _max_rho_after(h, vm))
    return best.host_id
