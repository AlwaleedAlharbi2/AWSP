"""
PABFD – Power-Aware Best-Fit Decreasing [15].

Ref: A. Beloglazov and R. Buyya, "Optimal Online Deterministic Algorithms
and Adaptive Heuristics for Energy and Performance Efficient Dynamic
Consolidation of Virtual Machines in Cloud Data Centers,"
Concurrency and Computation: Practice and Experience, 2012.

Algorithm:
  1. Sort incoming VMs by CPU demand (decreasing).
  2. For each VM, select the host that:
     - can accommodate the VM (feasibility check)
     - minimises the increase in total system power after placement.
  3. If no active host fits, activate the least-loaded inactive host.
"""

from __future__ import annotations
import numpy as np
from typing import List

from ..models import Host, VM, CPU, N_RES


def _power_increase(host: Host, vm: VM) -> float:
    """Estimate power increase if vm is placed on host (eq. 1 linearisation)."""
    if not host.is_active:
        return host.p_idle + (host.p_max - host.p_idle) * (
            (host.utilization[CPU] + vm.demands[CPU]) /
            (host.capacities[CPU] + 1e-12)
        ) - 0.0   # previously drawing 0 W (inactive)
    before = host.power()
    after  = host.p_idle + (host.p_max - host.p_idle) * (
        (host.utilization[CPU] + vm.demands[CPU]) /
        (host.capacities[CPU] + 1e-12)
    )
    return after - before


def pabfd_policy(hosts: List[Host], vm: VM, *,
                 theta: np.ndarray,
                 weights: np.ndarray,
                 alpha: float,
                 k: int,
                 rng: np.random.Generator,
                 exclude: int = -1) -> int:
    """
    PABFD placement policy.
    Returns host_id of selected host, or -1 if no feasible host exists.
    """
    feasible = [
        h for h in hosts
        if h.host_id != exclude and h.can_fit(vm.demands, theta)
    ]
    if not feasible:
        return -1

    best = min(feasible, key=lambda h: _power_increase(h, vm))
    return best.host_id
