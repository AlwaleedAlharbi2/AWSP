"""Baseline VM-placement policies."""
from .pabfd      import pabfd_policy
from .grvmp      import grvmp_policy
from .lbmbp      import lbmbp_policy
from .entropy_vmp import entropy_vmp_policy
from .hunter     import hunter_policy
from .k_rl_vmp   import k_rl_vmp_policy

BASELINES = {
    "PABFD":       pabfd_policy,
    "GRVMP":       grvmp_policy,
    "LBMBP":       lbmbp_policy,
    "Entropy-VMP": entropy_vmp_policy,
    "HUNTER":      hunter_policy,
    "K-RL-VMP":    k_rl_vmp_policy,
}

__all__ = list(BASELINES.keys()) + ["BASELINES"]
