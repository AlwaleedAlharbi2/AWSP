"""
HUNTER – Heuristic Utilisation-awareNEighbouR placement [33].

Algorithm:
  HUNTER uses a two-stage placement:
  Stage 1 – Filter: retain hosts whose post-placement CPU utilisation
             stays below a target threshold (typically 0.7).
  Stage 2 – Score: among filtered hosts, choose the one maximising
             a weighted combination of (a) RAM residual slack and
             (b) inverse of CPU utilisation increase, to jointly
             address CPU hotspot avoidance and RAM fragmentation.

  If no host passes the filter, fall back to the best-fit host by
  CPU utilisation increase.
"""

from __future__ import annotations
import numpy as np
from typing import List

from ..models import Host, VM, CPU, RAM, N_RES

CPU_THRESHOLD = 0.70   # HUNTER filter threshold


def _hunter_score(host: Host, vm: VM, theta: np.ndarray,
                  weights: np.ndarray) -> float:
    cpu_util_after = (host.utilization[CPU] + vm.demands[CPU]) / (
        host.capacities[CPU] + 1e-12
    )
    cpu_term = 1.0 / (cpu_util_after + 1e-3)
    ram_residual = max(
        theta[RAM] * host.capacities[RAM] -
        host.utilization[RAM] - vm.demands[RAM], 0.0
    )
    return weights[CPU] * cpu_term + weights[RAM] * ram_residual


def hunter_policy(hosts: List[Host], vm: VM, *,
                  theta: np.ndarray,
                  weights: np.ndarray,
                  alpha: float,
                  k: int,
                  rng: np.random.Generator,
                  exclude: int = -1) -> int:
    """HUNTER placement policy. Returns host_id or -1."""
    feasible = [
        h for h in hosts
        if h.host_id != exclude and h.can_fit(vm.demands, theta)
    ]
    if not feasible:
        return -1

    # Stage 1: filter by CPU threshold
    filtered = [
        h for h in feasible
        if (h.utilization[CPU] + vm.demands[CPU]) /
           (h.capacities[CPU] + 1e-12) <= CPU_THRESHOLD
    ]
    pool = filtered if filtered else feasible

    # Stage 2: score
    best = max(pool, key=lambda h: _hunter_score(h, vm, theta, weights))
    return best.host_id
