"""
Entropy-VMP – Entropy-based VM Placement [24].

Algorithm:
  Uses differential entropy of the per-resource utilisation distribution
  to guide placement toward maximising resource diversity (entropy).
  Placing a VM on a host that increases entropy is preferred, as higher
  entropy indicates more balanced multi-resource utilisation across the
  data centre (anti-fragmentation objective).

  For each feasible host h, compute the change in global entropy:
      ΔH = H(rho_new) - H(rho_old)
  where the entropy H is computed over all active hosts' dominant
  utilisation dimension.
"""

from __future__ import annotations
import numpy as np
from typing import List

from ..models import Host, VM, N_RES


def _utilisation_entropy(hosts: List[Host]) -> float:
    """Shannon entropy of the utilisation levels across active hosts."""
    rhos = np.array([h.rho()[h.dominant_resource()] for h in hosts
                     if h.is_active])
    if len(rhos) == 0:
        return 0.0
    # Bin into deciles
    counts, _ = np.histogram(rhos, bins=10, range=(0.0, 1.0))
    probs = counts / (counts.sum() + 1e-12)
    probs = probs[probs > 0]
    return float(-np.sum(probs * np.log2(probs + 1e-12)))


def entropy_vmp_policy(hosts: List[Host], vm: VM, *,
                       theta: np.ndarray,
                       weights: np.ndarray,
                       alpha: float,
                       k: int,
                       rng: np.random.Generator,
                       exclude: int = -1) -> int:
    """Entropy-VMP placement policy. Returns host_id or -1."""
    feasible = [
        h for h in hosts
        if h.host_id != exclude and h.can_fit(vm.demands, theta)
    ]
    if not feasible:
        return -1

    # Score each candidate: prefer higher post-placement entropy
    def _entropy_gain(host: Host) -> float:
        # Simulate placement
        host.utilization += vm.demands
        e_after = _utilisation_entropy(hosts)
        host.utilization -= vm.demands
        return e_after

    best = max(feasible, key=_entropy_gain)
    return best.host_id
