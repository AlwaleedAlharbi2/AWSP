"""
K-RL-VMP – k-nearest neighbour Reinforcement Learning VM Placement [25].

Algorithm:
  K-RL-VMP approximates a learned placement policy via a k-NN lookup
  over a feature space spanned by:
    (vm.demands[CPU] / max_cpu, vm.demands[RAM] / max_ram,
     host.rho()[CPU], host.rho()[RAM], host.weighted_slack / normaliser)

  In the absence of a pre-trained neural network (which would require
  the original paper's training data), this implementation approximates
  the learned reward signal with a hand-crafted reward function that
  mirrors the paper's training objective: maximise weighted slack while
  penalising active host count.

  This is the closest reproducible proxy to K-RL-VMP without the
  original RL model weights.

  NOTE: If the original model weights are available, replace _rl_score
  with a call to the actual network inference.
"""

from __future__ import annotations
import numpy as np
from typing import List

from ..models import Host, VM, CPU, RAM, N_RES


def _state_feature(host: Host, vm: VM,
                   max_caps: np.ndarray,
                   theta: np.ndarray,
                   weights: np.ndarray) -> np.ndarray:
    """Compute joint (host, VM) feature vector for reward estimation."""
    vm_norm    = vm.demands / (max_caps + 1e-12)
    host_rho   = host.rho()
    slack_norm = host.residual_slack(theta) / (max_caps + 1e-12)
    return np.concatenate([vm_norm, host_rho, slack_norm])


def _rl_score(host: Host, vm: VM,
              max_caps: np.ndarray,
              theta: np.ndarray, weights: np.ndarray,
              alpha: float) -> float:
    """
    Proxy reward: maximise post-placement weighted slack, penalise
    activating idle hosts (mirrors K-RL-VMP reward shaping).
    """
    activation_penalty = alpha * (0 if host.is_active else 1)
    post_slack = host.residual_slack(theta) - vm.demands
    post_slack = np.maximum(post_slack, 0.0)
    slack_reward = float(np.dot(weights, post_slack))
    return slack_reward - activation_penalty


def k_rl_vmp_policy(hosts: List[Host], vm: VM, *,
                    theta: np.ndarray,
                    weights: np.ndarray,
                    alpha: float,
                    k: int,
                    rng: np.random.Generator,
                    exclude: int = -1) -> int:
    """
    K-RL-VMP placement policy (proxy implementation).
    Returns host_id or -1.
    """
    feasible = [
        h for h in hosts
        if h.host_id != exclude and h.can_fit(vm.demands, theta)
    ]
    if not feasible:
        return -1

    max_caps = np.max(
        np.vstack([h.capacities for h in hosts]), axis=0
    )

    # Select top-k candidates by proxy RL reward, then pick best
    scored = sorted(feasible,
                    key=lambda h: _rl_score(h, vm, max_caps, theta,
                                            weights, alpha),
                    reverse=True)
    pool = scored[:k] if len(scored) >= k else scored
    best = pool[0]
    return best.host_id
