"""
Lightweight cloud data-centre simulator (Python equivalent of CloudSim 7).

Supports:
  - Online VM arrival/departure stream
  - Pluggable placement policy
  - Linear power model (Beloglazov & Buyya 2012)
  - SLA tracking (headroom-based violations)
  - Migration energy and SLA cost
  - Diurnal and bursty workload patterns

Usage:
    sim = Simulator(hosts, policy, theta, weights, seed=42)
    result = sim.run(vm_stream, window_seconds=86400)
"""

from __future__ import annotations
import time
import copy
import numpy as np
from typing import List, Callable, Tuple, Optional

from .models import VM, Host, PlacementResult, CPU, N_RES


# ---------------------------------------------------------------------------
# Workload stream helpers
# ---------------------------------------------------------------------------

def make_vm(vm_id: int, demands: np.ndarray, arrival: float,
            lifetime: float, memory_mb: float = 4096.0) -> VM:
    vm = VM(vm_id=vm_id, demands=demands, lifetime=lifetime,
            arrival_time=arrival, memory_mb=memory_mb)
    vm.departure_time = arrival + lifetime
    return vm


def synthetic_google_stream(n_vms: int, n_hosts: int, seed: int = 42,
                             window: float = 86400.0) -> List[VM]:
    """Synthetic diurnal stream calibrated to Google Cluster v3 statistics."""
    rng = np.random.default_rng(seed)
    # Diurnal arrival rate: low at night, peak at midday
    t = np.linspace(0, window, n_vms)
    # Poisson spacing modulated by a diurnal factor
    inter_arr = window / n_vms * (0.6 + 0.4 * np.sin(np.pi * t / window) ** 2)
    arrivals = np.cumsum(inter_arr)
    arrivals = arrivals / arrivals[-1] * window * 0.99

    max_cap = np.array([16.0, 192.0, 0.0])   # Google trace: no BW
    vms = []
    for i in range(n_vms):
        # Mix of CPU-heavy, RAM-heavy, balanced
        kind = rng.integers(3)
        if kind == 0:   # CPU-heavy
            d = np.array([rng.uniform(0.5, 3.0),
                          rng.uniform(0.5, 4.0),
                          0.0])
        elif kind == 1: # RAM-heavy
            d = np.array([rng.uniform(0.1, 1.0),
                          rng.uniform(4.0, 24.0),
                          0.0])
        else:           # balanced
            d = np.array([rng.uniform(0.2, 2.0),
                          rng.uniform(1.0, 12.0),
                          0.0])
        lifetime = rng.exponential(scale=window / 10.0)
        vms.append(make_vm(i, d, arrivals[i], lifetime))
    return vms


def synthetic_azure_stream(n_vms: int, n_hosts: int, seed: int = 42,
                            window: float = 1209600.0) -> List[VM]:
    """Synthetic stream calibrated to Azure Packing 2020 (14-day window)."""
    rng = np.random.default_rng(seed)
    arrivals = np.sort(rng.uniform(0, window * 0.99, n_vms))
    vms = []
    for i in range(n_vms):
        kind = rng.integers(3)
        if kind == 0:
            d = np.array([rng.uniform(1.0, 4.0), rng.uniform(0.5, 8.0), 0.0])
        elif kind == 1:
            d = np.array([rng.uniform(0.5, 2.0), rng.uniform(8.0, 32.0), 0.0])
        else:
            d = np.array([rng.uniform(0.5, 3.0), rng.uniform(1.0, 16.0), 0.0])
        lifetime = rng.exponential(scale=window / 20.0)
        vms.append(make_vm(i, d, arrivals[i], lifetime))
    return vms


def synthetic_bitbrains_stream(n_vms: int = 1750, seed: int = 42,
                                window: float = 2592000.0) -> List[VM]:
    """Synthetic stream calibrated to Bitbrains GWA-T-12 (30-day, 3 resources)."""
    rng = np.random.default_rng(seed)
    arrivals = np.sort(rng.uniform(0, window * 0.8, n_vms))
    vms = []
    for i in range(n_vms):
        # Enterprise: mostly CPU- or RAM-heavy, with BW
        kind = rng.choice([0, 1], p=[0.55, 0.45])  # FastStorage vs Rnd
        if kind == 0:   # CPU-heavy (FastStorage)
            d = np.array([rng.uniform(1.0, 6.0),
                          rng.uniform(1.0, 8.0),
                          rng.uniform(0.1, 1.0)])
        else:           # RAM-heavy (Rnd)
            d = np.array([rng.uniform(0.5, 2.0),
                          rng.uniform(8.0, 48.0),
                          rng.uniform(0.1, 0.5)])
        lifetime = rng.exponential(scale=window / 5.0)
        vms.append(make_vm(i, d, arrivals[i], lifetime))
    return vms


# ---------------------------------------------------------------------------
# Simulator
# ---------------------------------------------------------------------------

class Simulator:
    """
    Event-driven VM placement simulator.

    Parameters
    ----------
    hosts       : list of Host objects (copied internally)
    policy      : callable(hosts, vm, theta, weights, alpha, k, rng) -> host_id
    theta       : headroom factors, shape (N_RES,)
    weights     : resource weights for slack, shape (N_RES,)
    alpha       : activation cost weight in ILP objective
    k           : sampling parameter (used by AWSP++ and power-of-k baselines)
    lambda_sla  : SLA weighting coefficient in migration cost
    seed        : random seed
    """

    def __init__(self, hosts: List[Host], policy, *,
                 theta: np.ndarray,
                 weights: np.ndarray,
                 alpha: float = 1.0,
                 beta: float  = 0.5,
                 k: int = 4,
                 lambda_sla: float = 1.0,
                 rebalance_interval: float = 3600.0,
                 seed: int = 42):
        self.hosts    = [copy.deepcopy(h) for h in hosts]
        self.policy   = policy
        self.theta    = theta
        self.weights  = weights
        self.alpha    = alpha
        self.beta     = beta
        self.k        = k
        self.lambda_sla = lambda_sla
        self.rebal_interval = rebalance_interval
        self.rng = np.random.default_rng(seed)

        self._host_map: dict = {h.host_id: h for h in self.hosts}
        self._vm_map:   dict = {}

        # Metrics
        self._total_energy_ws: float = 0.0
        self._last_event_time: float = 0.0
        self._sla_violations: int  = 0
        self._total_vms: int  = 0
        self._migrations: int = 0
        self._decision_times: List[float] = []
        self._peak_active_hosts: int = 0
        self._active_host_samples: List[int] = []
        self._sample_interval: float = 600.0   # sample every 10 min

    # ------------------------------------------------------------------
    def run(self, vm_stream: List[VM],
            window: float,
            dataset: str = 'generic',
            algorithm: str = 'unknown',
            seed: int = 0) -> PlacementResult:
        """
        Process all VMs in arrival-time order, tracking metrics.
        Returns a PlacementResult.
        """
        # Build event queue: (time, event_type, vm)
        events: List[Tuple[float, str, VM]] = []
        for vm in vm_stream:
            events.append((vm.arrival_time,   'arrive',  vm))
            events.append((vm.departure_time, 'depart',  vm))
        events.sort(key=lambda e: e[0])

        next_rebal  = self.rebal_interval
        next_sample = self._sample_interval

        for event_time, etype, vm in events:
            self._account_energy(event_time)

            if etype == 'arrive':
                self._handle_arrival(vm)
            else:
                self._handle_departure(vm)

            # Periodic active-host sampling
            if event_time >= next_sample:
                n_now = sum(1 for h in self.hosts if h.is_active)
                self._active_host_samples.append(n_now)
                if n_now > self._peak_active_hosts:
                    self._peak_active_hosts = n_now
                next_sample += self._sample_interval

            # Periodic rebalancing
            if event_time >= next_rebal:
                self._rebalance()
                next_rebal += self.rebal_interval

        self._account_energy(window)

        # Final sample
        n_now = sum(1 for h in self.hosts if h.is_active)
        self._active_host_samples.append(n_now)
        if n_now > self._peak_active_hosts:
            self._peak_active_hosts = n_now

        # Use peak active hosts (paper metric = max active hosts during sim)
        n_active  = self._peak_active_hosts
        total_slack = sum(
            float(np.dot(self.weights, h.residual_slack(self.theta)))
            for h in self.hosts if h.is_active
        )
        sla_rate = (self._sla_violations / max(self._total_vms, 1)) * 100
        energy_kwh = self._total_energy_ws / 3_600_000.0
        avg_ms = (np.mean(self._decision_times) * 1000.0
                  if self._decision_times else 0.0)

        return PlacementResult(
            algorithm      = algorithm,
            dataset        = dataset,
            seed           = seed,
            active_hosts   = n_active,
            energy_kwh     = energy_kwh,
            weighted_slack = total_slack,
            sla_rate       = sla_rate,
            migration_count= self._migrations,
            avg_decision_ms= avg_ms,
        )

    # ------------------------------------------------------------------
    def _account_energy(self, now: float) -> None:
        dt = now - self._last_event_time
        if dt > 0:
            self._total_energy_ws += sum(h.power() * dt for h in self.hosts)
        self._last_event_time = now

    def _handle_arrival(self, vm: VM) -> None:
        self._total_vms += 1
        t0 = time.perf_counter()
        host_id = self.policy(
            self.hosts, vm,
            theta=self.theta, weights=self.weights,
            alpha=self.alpha, k=self.k, rng=self.rng
        )
        self._decision_times.append(time.perf_counter() - t0)

        if host_id < 0:
            self._sla_violations += 1
            return

        host = self._host_map[host_id]
        host.place(vm)
        vm.host_id = host_id
        self._vm_map[vm.vm_id] = vm

        # Check immediate headroom violation
        if not np.all(host.utilization <= self.theta * host.capacities):
            self._sla_violations += 1

    def _handle_departure(self, vm: VM) -> None:
        if vm.vm_id not in self._vm_map:
            return
        host = self._host_map.get(vm.host_id)
        if host is not None:
            host.remove(vm)
        del self._vm_map[vm.vm_id]

    def _rebalance(self) -> None:
        """Simplified rebalancing: migrate VMs off underloaded hosts."""
        tau_down = 0.20
        eps_up   = 0.05
        for host in list(self.hosts):
            if not host.is_active:
                continue
            rho = host.rho()
            # Underloaded: try to consolidate
            if np.dot(self.weights[:len(rho)], rho) < tau_down:
                for vm_id in list(host.vms):
                    vm = self._vm_map.get(vm_id)
                    if vm is None:
                        continue
                    # Find destination
                    dest_id = self.policy(
                        self.hosts, vm,
                        theta=self.theta, weights=self.weights,
                        alpha=self.alpha, k=self.k, rng=self.rng,
                        exclude=host.host_id
                    )
                    if dest_id >= 0 and dest_id != host.host_id:
                        host.remove(vm)
                        dest = self._host_map[dest_id]
                        dest.place(vm)
                        vm.host_id = dest_id
                        self._migrations += 1
