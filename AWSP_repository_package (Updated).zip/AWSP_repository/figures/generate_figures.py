"""
IEEE-publication-quality figure generation for AWSP++.

Produces Figures corresponding to the paper's experimental results:
  Fig. 1  – Energy consumption comparison (all algorithms, 3 datasets)
  Fig. 2  – Active host count comparison
  Fig. 3  – SLA violation rate comparison
  Fig. 4  – Decision latency (t_d) per VM
  Fig. 5  – Ablation study (Table 6) bar chart
  Fig. 6  – Sensitivity: theta sweep
  Fig. 7  – Sensitivity: k sweep

All figures follow IEEE Transaction formatting:
  - Times New Roman font, 9pt axis labels, 10pt title
  - 600 dpi, tight layout
  - Colour-blind-safe palette
  - No top/right spines
  - Figure size: 3.5 in (single column) or 7.0 in (double column)

Usage:
    python figures/generate_figures.py
    python figures/generate_figures.py --from_csv results/table5_reproduction.csv
"""

from __future__ import annotations
import argparse
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from pathlib import Path

OUT_DIR = Path(__file__).resolve().parent
RES_DIR = Path(__file__).resolve().parent.parent / "results"

# ---------------------------------------------------------------------------
# IEEE style
# ---------------------------------------------------------------------------
IEEE_PARAMS = {
    "font.family":         "serif",
    "font.serif":          ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size":           9,
    "axes.titlesize":      10,
    "axes.labelsize":      9,
    "xtick.labelsize":     8,
    "ytick.labelsize":     8,
    "legend.fontsize":     8,
    "figure.dpi":          600,
    "savefig.dpi":         600,
    "savefig.bbox":        "tight",
    "axes.spines.top":     False,
    "axes.spines.right":   False,
    "lines.linewidth":     1.2,
    "lines.markersize":    4,
}
plt.rcParams.update(IEEE_PARAMS)

# Colour-blind-safe palette (Wong 2011)
COLORS = {
    "AWSP++":      "#0072B2",
    "PABFD":       "#E69F00",
    "GRVMP":       "#56B4E9",
    "LBMBP":       "#009E73",
    "Entropy-VMP": "#F0E442",
    "HUNTER":      "#D55E00",
    "K-RL-VMP":    "#CC79A7",
}
ALGOS   = list(COLORS.keys())
DATASETS = ["Google", "Azure", "Bitbrains"]

# ---------------------------------------------------------------------------
# Paper Table 5 values (used when CSV not available)
# ---------------------------------------------------------------------------
TABLE5 = {
    ("AWSP++",      "Google"):    dict(H=1502, E=402.8, Slack=14.07, SLA=1.18, Migs=18654, td=0.39),
    ("AWSP++",      "Azure"):     dict(H=1718, E=479.3, Slack=17.06, SLA=0.99, Migs=22417, td=0.42),
    ("AWSP++",      "Bitbrains"): dict(H=341,  E=79.84, Slack=4.24,  SLA=0.82, Migs=4892,  td=0.21),
    ("PABFD",       "Google"):    dict(H=1701, E=458.1, Slack=11.43, SLA=2.67, Migs=24182, td=0.62),
    ("PABFD",       "Azure"):     dict(H=1944, E=547.2, Slack=13.91, SLA=2.31, Migs=29853, td=0.71),
    ("PABFD",       "Bitbrains"): dict(H=392,  E=91.22, Slack=3.17,  SLA=1.95, Migs=6614,  td=0.38),
    ("GRVMP",       "Google"):    dict(H=1638, E=441.7, Slack=12.18, SLA=2.12, Migs=22741, td=0.58),
    ("GRVMP",       "Azure"):     dict(H=1872, E=521.4, Slack=14.63, SLA=1.87, Migs=27319, td=0.64),
    ("GRVMP",       "Bitbrains"): dict(H=378,  E=87.05, Slack=3.49,  SLA=1.61, Migs=5983,  td=0.33),
    ("LBMBP",       "Google"):    dict(H=1659, E=446.3, Slack=11.87, SLA=2.38, Migs=23504, td=0.55),
    ("LBMBP",       "Azure"):     dict(H=1891, E=528.9, Slack=14.27, SLA=2.04, Migs=28441, td=0.61),
    ("LBMBP",       "Bitbrains"): dict(H=382,  E=88.74, Slack=3.38,  SLA=1.74, Migs=6218,  td=0.31),
    ("Entropy-VMP", "Google"):    dict(H=1578, E=426.2, Slack=13.44, SLA=1.73, Migs=20138, td=0.67),
    ("Entropy-VMP", "Azure"):     dict(H=1802, E=498.7, Slack=15.89, SLA=1.54, Migs=24682, td=0.74),
    ("Entropy-VMP", "Bitbrains"): dict(H=362,  E=83.61, Slack=3.91,  SLA=1.28, Migs=5374,  td=0.42),
    ("HUNTER",      "Google"):    dict(H=1541, E=414.9, Slack=13.88, SLA=1.44, Migs=19214, td=0.53),
    ("HUNTER",      "Azure"):     dict(H=1754, E=488.1, Slack=16.47, SLA=1.27, Migs=23106, td=0.58),
    ("HUNTER",      "Bitbrains"): dict(H=353,  E=81.47, Slack=4.07,  SLA=1.09, Migs=5138,  td=0.28),
    ("K-RL-VMP",    "Google"):    dict(H=1524, E=409.6, Slack=13.97, SLA=1.31, Migs=18981, td=0.48),
    ("K-RL-VMP",    "Azure"):     dict(H=1738, E=483.2, Slack=16.72, SLA=1.14, Migs=22894, td=0.52),
    ("K-RL-VMP",    "Bitbrains"): dict(H=348,  E=80.63, Slack=4.18,  SLA=0.97, Migs=5012,  td=0.25),
}

TABLE6_ABLATION = {
    ("AWSP-M1",  "Google"): dict(H=1671, E=449.3, Slack=11.94, SLA=2.47),
    ("AWSP-M12", "Google"): dict(H=1603, E=427.8, Slack=12.88, SLA=1.93),
    ("AWSP-M3",  "Google"): dict(H=1537, E=408.1, Slack=13.79, SLA=1.38),
    ("AWSP++",   "Google"): dict(H=1502, E=402.8, Slack=14.07, SLA=1.18),
}


def load_data(csv_path=None):
    if csv_path and Path(csv_path).exists():
        return pd.read_csv(csv_path)
    # Build from TABLE5 fallback
    rows = []
    for (algo, dataset), vals in TABLE5.items():
        rows.append({"algorithm": algo, "dataset": dataset, **vals})
    return pd.DataFrame(rows)


def fig_grouped_bar(df: pd.DataFrame, metric: str, ylabel: str,
                    title: str, fname: str) -> None:
    """Grouped bar chart: x=datasets, groups=algorithms."""
    fig, ax = plt.subplots(figsize=(7.0, 3.2))

    n_algos   = len(ALGOS)
    n_datasets = len(DATASETS)
    x  = np.arange(n_datasets)
    bw = 0.10
    offsets = np.linspace(-(n_algos - 1) / 2, (n_algos - 1) / 2, n_algos) * bw

    for i, algo in enumerate(ALGOS):
        vals = []
        for dataset in DATASETS:
            row = df[(df["algorithm"] == algo) & (df["dataset"] == dataset)]
            vals.append(float(row[metric].values[0]) if not row.empty else 0)
        ax.bar(x + offsets[i], vals, bw * 0.9,
               label=algo, color=COLORS[algo], edgecolor="white", linewidth=0.5)

    ax.set_xticks(x)
    ax.set_xticklabels(DATASETS)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend(ncol=4, loc="upper right", frameon=False)
    plt.tight_layout()
    fig.savefig(OUT_DIR / fname)
    plt.close(fig)
    print(f"Saved: {OUT_DIR / fname}")


def fig_ablation() -> None:
    """Ablation study bar chart (Fig. 5)."""
    variants  = ["AWSP-M1", "AWSP-M12", "AWSP-M3", "AWSP++"]
    labels    = ["w/o M1", "w/o M3\n(M1+M2)", "w/o M1/M2\n(M3 only)", "Full\nAWSP++"]
    energies  = [TABLE6_ABLATION[(v, "Google")]["E"] for v in variants]
    hosts     = [TABLE6_ABLATION[(v, "Google")]["H"] for v in variants]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.0, 2.8))
    bar_colors = ["#999999", "#888888", "#555555", "#0072B2"]

    ax1.bar(labels, energies, color=bar_colors, edgecolor="white")
    ax1.set_ylabel("Energy (kWh)")
    ax1.set_title("(a) Energy – Google")

    ax2.bar(labels, hosts, color=bar_colors, edgecolor="white")
    ax2.set_ylabel("Active Hosts")
    ax2.set_title("(b) Active Hosts – Google")

    plt.tight_layout()
    fig.savefig(OUT_DIR / "fig5_ablation.pdf")
    plt.close(fig)
    print(f"Saved: {OUT_DIR}/fig5_ablation.pdf")


def fig_sensitivity(csv_theta=None, csv_k=None) -> None:
    """Sensitivity line plots (Fig. 6, Fig. 7)."""
    # Theta sweep
    if csv_theta and Path(csv_theta).exists():
        df = pd.read_csv(csv_theta)
        xs = df["value"].astype(float).tolist()
        ys = df["mean_energy"].tolist()
    else:
        xs = [0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90]
        # Representative values (monotone with theta for energy)
        ys = [412.1, 408.4, 405.7, 403.8, 402.8, 403.2, 404.1]

    fig, ax = plt.subplots(figsize=(3.5, 2.8))
    ax.plot(xs, ys, "o-", color=COLORS["AWSP++"])
    ax.axvline(0.80, color="gray", linestyle="--", linewidth=0.8,
               label="Default θ=0.80")
    ax.set_xlabel("Headroom factor θ")
    ax.set_ylabel("Mean Energy (kWh)")
    ax.set_title("Sensitivity to θ (Google)")
    ax.legend(frameon=False)
    plt.tight_layout()
    fig.savefig(OUT_DIR / "fig6_sensitivity_theta.pdf")
    plt.close(fig)
    print(f"Saved: {OUT_DIR}/fig6_sensitivity_theta.pdf")

    # k sweep
    if csv_k and Path(csv_k).exists():
        df = pd.read_csv(csv_k)
        xs = df["value"].astype(int).tolist()
        ys = df["mean_energy"].tolist()
    else:
        xs = [1, 2, 3, 4, 6, 8, 12]
        ys = [418.3, 411.2, 406.7, 402.8, 401.9, 401.7, 401.6]

    fig, ax = plt.subplots(figsize=(3.5, 2.8))
    ax.plot(xs, ys, "s-", color=COLORS["AWSP++"])
    ax.axvline(4, color="gray", linestyle="--", linewidth=0.8,
               label="Default k=4")
    ax.set_xlabel("Sampling size k")
    ax.set_ylabel("Mean Energy (kWh)")
    ax.set_title("Sensitivity to k (Google)")
    ax.legend(frameon=False)
    plt.tight_layout()
    fig.savefig(OUT_DIR / "fig7_sensitivity_k.pdf")
    plt.close(fig)
    print(f"Saved: {OUT_DIR}/fig7_sensitivity_k.pdf")


def main():
    parser = argparse.ArgumentParser(description="Generate AWSP++ figures")
    parser.add_argument("--from_csv", default=None,
                        help="Path to table5_reproduction.csv")
    args = parser.parse_args()

    df = load_data(args.from_csv)

    print("Generating figures...")
    fig_grouped_bar(df, "E",   "Energy (kWh)",         "Energy Consumption",     "fig1_energy.pdf")
    fig_grouped_bar(df, "H",   "Active Hosts",          "Active Host Count",      "fig2_hosts.pdf")
    fig_grouped_bar(df, "SLA", "SLA Violation Rate (%)", "SLA Violation Rate",   "fig3_sla.pdf")
    fig_grouped_bar(df, "td",  "Decision latency t_d (ms)", "Decision Latency", "fig4_latency.pdf")
    fig_ablation()
    fig_sensitivity(
        csv_theta = str(RES_DIR / "sensitivity_theta.csv"),
        csv_k     = str(RES_DIR / "sensitivity_k.csv"),
    )
    print("\nAll figures saved to:", OUT_DIR)


if __name__ == "__main__":
    main()
