"""Checks tied to the paper's Proposition V-C and the statistics paragraph."""
import os, sys, random
from math import comb
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import p_from_d, critical_d, min_exact_wilcoxon_p, min_seeds_for_wilcoxon, bonferroni_threshold
from model import power_of_k_sample


def test_tail_probability_non_increasing_in_k():
    N, m = 20, 7
    tails = [comb(N - m, k) / comb(N, k) for k in range(1, N - m + 1)]
    assert all(a >= b for a, b in zip(tails, tails[1:]))


def test_sampler_is_without_replacement_and_min_decreases():
    rng = random.Random(0)
    scores = list(range(100))
    class H:  # stand-in host
        def __init__(s, v): s.v = v
    hosts = [H(v) for v in scores]
    s = power_of_k_sample(hosts, 8, rng)
    assert len({id(h) for h in s}) == 8
    def mean_min(k, reps=3000):
        r = random.Random(1)
        return sum(min(h.v for h in power_of_k_sample(hosts, k, r)) for _ in range(reps)) / reps
    assert mean_min(2) > mean_min(4) > mean_min(8)


def test_wilcoxon_and_bonferroni_facts():
    assert abs(min_exact_wilcoxon_p(5) - 0.0625) < 1e-12
    assert min_seeds_for_wilcoxon() == 11
    assert abs(bonferroni_threshold(30) - 0.05 / 30) < 1e-12


def test_critical_d_matches_paper_text():
    assert 3.3 < critical_d(5) < 3.45          # "about 3.37"
    assert p_from_d(3.3) > bonferroni_threshold()   # d <= 3.3 fails
    assert p_from_d(3.6) < bonferroni_threshold()   # d = 3.6 passes
