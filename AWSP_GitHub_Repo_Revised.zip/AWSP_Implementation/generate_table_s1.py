"""
generate_table_s1.py - Supplementary Table S1: per-seed standard deviations.

Table S1 reports, for every dataset, algorithm and headline metric, the mean and the
sample standard deviation (ddof = 1) across the five seeds {17, 42, 73, 128, 257}
that underlie the means in Table 5 of the paper.

Two ways to build it:

1. From the per-seed result files of your full-scale runs (recommended; use the
   same runs that produced Table 5 and Table 8):
       python generate_table_s1.py --from_csv results/eval_google.csv \\
              results/eval_azure.csv results/eval_bitbrains.csv

2. By running the simulation here (small default scale; synthetic traces unless
   --real_data is given):
       python generate_table_s1.py --run --real_data --n_hosts 1000 --n_vms 50000

Outputs (in results/):  table_s1_per_seed_std.csv   long format incl. the five per-seed values
                        table_s1_per_seed_std.md    Markdown table "mean (std)"

IMPORTANT: standard deviations are only meaningful for the runs that produced the
paper's means. Numbers generated from synthetic traces or from the proxy baselines
(see README) must not be reported as the paper's Table S1.
"""
import os
import argparse
import pandas as pd
from config import RANDOM_SEEDS, RESULTS_DIR

METRICS = ["active_hosts", "energy_kwh", "weighted_slack", "sla_violation_rate", "avg_decision_time_ms"]
LABELS = {"active_hosts": "|H_act|", "energy_kwh": "E (kWh)", "weighted_slack": "Slack",
          "sla_violation_rate": "SLA (%)", "avg_decision_time_ms": "t_d (ms)"}


def build(df: pd.DataFrame) -> pd.DataFrame:
    missing = set(RANDOM_SEEDS) - set(df["seed"].unique())
    if missing:
        raise SystemExit(f"Missing seeds in results: {sorted(missing)}")
    rows = []
    for (ds, alg), g in df.groupby(["dataset", "algorithm"], sort=False):
        g = g.sort_values("seed")
        for m in METRICS:
            v = g[m].astype(float)
            rows.append({"dataset": ds, "algorithm": alg, "metric": m,
                         "mean": v.mean(), "std": v.std(ddof=1),
                         **{f"seed_{s}": x for s, x in zip(g["seed"], v)}})
    return pd.DataFrame(rows)


def to_markdown(long: pd.DataFrame) -> str:
    out = []
    for ds, g in long.groupby("dataset", sort=False):
        out.append(f"\n**{ds}**\n")
        out.append("| Algorithm | " + " | ".join(LABELS[m] for m in METRICS) + " |")
        out.append("| --- |" + " --- |" * len(METRICS))
        for alg, a in g.groupby("algorithm", sort=False):
            cells = []
            for m in METRICS:
                r = a[a["metric"] == m].iloc[0]
                cells.append(f"{r['mean']:.2f} ({r['std']:.2f})")
            out.append(f"| {alg} | " + " | ".join(cells) + " |")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="Generate supplementary Table S1")
    ap.add_argument("--from_csv", nargs="+", help="per-seed result CSVs written by evaluate.py")
    ap.add_argument("--run", action="store_true", help="run all datasets here")
    ap.add_argument("--real_data", action="store_true")
    ap.add_argument("--n_hosts", type=int, default=200)
    ap.add_argument("--n_vms", type=int, default=5000)
    ap.add_argument("--out", default=os.path.join(RESULTS_DIR, "table_s1_per_seed_std"))
    a = ap.parse_args()
    if a.from_csv:
        df = pd.concat([pd.read_csv(p) for p in a.from_csv], ignore_index=True)
    elif a.run:
        from evaluate import evaluate_all_methods
        df = pd.concat([evaluate_all_methods(d, n_vms=a.n_vms, n_hosts=a.n_hosts,
                                             use_synthetic=not a.real_data)
                        for d in ("google", "azure", "bitbrains")], ignore_index=True)
    else:
        ap.error("give --from_csv ... or --run")
    long = build(df)
    os.makedirs(RESULTS_DIR, exist_ok=True)
    long.to_csv(a.out + ".csv", index=False)
    open(a.out + ".md", "w", encoding="utf8").write(
        "# Supplementary Table S1: mean (standard deviation across five seeds)\n"
        f"Seeds: {RANDOM_SEEDS}\n" + to_markdown(long) + "\n")
    print("wrote", a.out + ".csv", "and", a.out + ".md")


if __name__ == "__main__":
    main()
