# Changelog

## Revised version (aligned with the revised IEEE Access manuscript)
- Titles and abstract wording updated; "heterogeneous data centers" removed (uniform host profile, VM-demand heterogeneity only).
- `dataset.py`: synthetic hosts are now uniform (Table 4); varied hosts only with `heterogeneous_hosts=True`.
- `model.py`: ablation switches `use_bucket`, `use_rebalancer`, `sampler="random_single"`; sampler documented as without replacement (Proposition V-C).
- `evaluate.py`: all six baseline names, proxy baselines tagged, Table 6 ablation (`--ablation`), Table 8 report with Bonferroni over 30 tests, `--real_data`.
- `utils.py`: `significance_report`, `p_from_d`, `critical_d`, Wilcoxon minimum-p helpers; paired t-test guards zero-variance differences.
- `generate_table_s1.py`: builds Table S1 (mean and std across seeds) from per-seed results.
- `tests/test_theory.py`: checks Proposition V-C and the statistics text.
- README: corrected percentage claims, scope statement, new commands.
